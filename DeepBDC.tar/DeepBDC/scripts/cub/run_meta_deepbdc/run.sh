./run_pretrain.sh
./run_metatrain.sh
./run_test.sh