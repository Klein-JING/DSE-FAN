#./run_pretrain.sh
#./run_distillation.sh
./run_test.sh