
save_dir                    = 'XJTU_Conv4/Distribution Calibration/'
data_dir = {}
data_dir['XJTU']             = 'XJTU_Conv4/Distribution Calibration/filelists/XJTU/' 
data_dir['MDP']             = 'XJTU_Conv4/Distribution Calibration/filelists/MDP/' 
data_dir['NUIG']    = 'XJTU_Conv4/Distribution Calibration/filelists/NUIG/' 