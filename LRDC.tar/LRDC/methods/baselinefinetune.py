import backbone
import torch
import torch.nn as nn
from torch.autograd import Variable
import numpy as np
import torch.nn.functional as F
from methods.meta_template import MetaTemplate
from sklearn.linear_model import LogisticRegression

class BaselineFinetune(MetaTemplate):
    def __init__(self, model_func,  n_way, n_support, loss_type = "dist"):
        super(BaselineFinetune, self).__init__( model_func,  n_way, n_support)
        self.loss_type = loss_type

    def set_forward(self,x,is_feature = True):
        return self.set_forward_adaptation(x,is_feature); #Baseline always do adaptation

    def distribution_calibration(self, query, base_means, base_cov, k=1, alpha=0.21):
        dist = []
        for i in range(len(base_means)):
            dist.append(np.linalg.norm(query-base_means[i]))
        index = np.argpartition(dist, k)[:k]
        mean = np.concatenate([np.array(base_means)[index], query[np.newaxis, :]])
        calibrated_mean = np.mean(mean, axis=0)
        calibrated_cov = np.mean(np.array(base_cov)[index], axis=0)+alpha
        return calibrated_mean, calibrated_cov

    def set_forward_adaptation(self, mean_base, cov_base, x, n_way = 5, n_support = 5, n_query = 15, is_feature = True):
        assert is_feature == True, 'Baseline only support testing with feature'
        support_data, query_data = self.parse_feature(x, is_feature)
        support_label, query_label = np.repeat(range(n_way), n_support), np.repeat(range(n_way), n_query)

        # ---- Tukey's transform
        beta = 0.4
        support_data = np.power(support_data, beta).reshape(n_way*n_support, -1)
        query_data = np.power(query_data, beta).reshape(n_way*n_query, -1)
        # ---- distribution calibration and feature sampling
        sampled_data = []
        sampled_label = []
        n_lsamples = len(support_data)
        num_sampled = int(100)
        for i in range(n_lsamples):
            mean, cov = self.distribution_calibration(support_data[i], mean_base, cov_base, k = 1, alpha = 0.21)
            sampled_data.append(np.random.multivariate_normal(mean=mean, cov=cov, size=num_sampled))
            sampled_label.extend([support_label[i]]*num_sampled)

        sampled_data = np.concatenate([sampled_data[:]]).reshape(n_way*n_support*num_sampled, -1)
        X_aug = np.concatenate([support_data, sampled_data])
        Y_aug = np.concatenate([support_label, sampled_label])

        # ---- train classifier
        classifier = LogisticRegression(max_iter=500).fit(X=X_aug, y=Y_aug)
        predicts = classifier.predict(query_data)
        # print('%s %d way %d shot  ACC : %f'%(dataset,n_ways,n_shot,float(np.mean(acc_list))))
        return predicts, query_label

        # X_aug = torch.tensor(X_aug).float().cuda()
        # Y_aug = torch.tensor(Y_aug).cuda()
        # # X_aug = torch.tensor(support_data).float().cuda()
        # # Y_aug = torch.tensor(support_label).cuda()
        # query_data = torch.tensor(query_data).float().cuda()
        # query_label = query_label

        # if self.loss_type == 'softmax':
        #     linear_clf = nn.Linear(self.feat_dim, self.n_way)
        # elif self.loss_type == 'dist':        
        #     linear_clf = backbone.distLinear(self.feat_dim, self.n_way)
        # linear_clf = linear_clf.cuda()

        # set_optimizer = torch.optim.SGD(linear_clf.parameters(), lr = 0.01, momentum=0.9, dampening=0.9, weight_decay=0.001)

        # loss_function = nn.CrossEntropyLoss()
        # loss_function = loss_function.cuda()
        
        # batch_size = 5
        # support_size = self.n_way* self.n_support
        # scores_eval = []
        # for epoch in range(901):
        #     rand_id = np.random.permutation(support_size)
        #     for i in range(0, support_size , batch_size):
        #         set_optimizer.zero_grad()
        #         selected_id = torch.from_numpy( rand_id[i: min(i+batch_size, support_size) ]).cuda()
        #         z_batch = X_aug[selected_id]
        #         y_batch = Y_aug[selected_id] 
        #         scores = linear_clf(z_batch)
        #         loss = loss_function(scores,y_batch)
        #         loss.backward()
        #         set_optimizer.step()
        #     if epoch %300 ==0 and epoch !=0:
        #         scores_eval.append(linear_clf(query_data))
        # return scores_eval, query_label


    def set_forward_loss(self,x):
        raise ValueError('Baseline predict on pretrained feature and do not support finetune backbone')
        

