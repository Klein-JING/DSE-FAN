from email.mime import base
import numpy as np
import torch
from torch.autograd import Variable
import os
import glob
import h5py

import configs
import backbone
from data.datamgr import SimpleDataManager
from methods.baselinetrain import BaselineTrain
from methods.baselinefinetune import BaselineFinetune
from methods.protonet import ProtoNet
from methods.matchingnet import MatchingNet
from methods.relationnet import RelationNet
from methods.maml import MAML
from io_utils import model_dict, parse_args, get_resume_file, get_best_file, get_assigned_file 
import wrn_mixup_model
import torch.nn as nn

class WrappedModel(nn.Module):
    def __init__(self, module):
        super(WrappedModel, self).__init__()
        self.module = module # that I actually define.
    def forward(self, x):
        return self.module(x)


def save_features(model, data_loader, outfile, params, split_base):
    f = h5py.File(outfile, 'w')
    max_count = len(data_loader)*data_loader.batch_size
    all_labels = f.create_dataset('all_labels',(max_count,), dtype='i')
    all_feats=None
    count=0
    for i, (x,y) in enumerate(data_loader):
        if i%10 == 0:
            print('{}: {:d}/{:d}'.format(split_base, i, len(data_loader)))

        if torch.cuda.is_available():
            x = x.cuda()
        x_var = Variable(x)
        if params.method == 'manifold_mixup' or params.method == 'S2M2_R':
            feats,_ = model(x_var)
        else:
            feats = model(x_var)
        if all_feats is None:
            all_feats = f.create_dataset('all_feats', [max_count] + list( feats.size()[1:]) , dtype='f')
        all_feats[count:count+feats.size(0)] = feats.data.cpu().numpy()
        all_labels[count:count+feats.size(0)] = y.cpu().numpy()
        count = count + feats.size(0)

    count_var = f.create_dataset('count', (1,), dtype='i')
    count_var[0] = count

    f.close()

if __name__ == '__main__':
    params = parse_args('save_features')
    params.dataset = 'NUIG'
    if params.dataset == 'XJTU':
        image_size = 84
    else:
        image_size = 84

    split_base = params.split_base
    split_novel = params.split_novel

    loadfile_base = configs.data_dir[params.dataset] + split_base + '.json'
    loadfile_novel = configs.data_dir[params.dataset] + split_novel + '.json'

    checkpoint_dir = '%s/checkpoints/%s/%s_%s' %(configs.save_dir, params.dataset, params.model, params.method)
    

    if params.save_iter != -1:
        modelfile   = get_assigned_file(checkpoint_dir,params.save_iter)
    else:
        modelfile   = get_resume_file(checkpoint_dir)
    
    if params.save_iter != -1:
        outfile_base = os.path.join( checkpoint_dir.replace("checkpoints","features"), split_base + "_" + str(params.save_iter)+ ".hdf5") 
        outfile_novel = os.path.join( checkpoint_dir.replace("checkpoints","features"), split_novel + "_" + str(params.save_iter)+ ".hdf5") 
    else:
        outfile_base = os.path.join( checkpoint_dir.replace("checkpoints","features"), split_base + ".hdf5") 
        outfile_novel = os.path.join( checkpoint_dir.replace("checkpoints","features"), split_novel + ".hdf5") 

    datamgr         = SimpleDataManager(image_size, batch_size = 3)
    data_loader_base     = datamgr.get_data_loader(loadfile_base, aug = False)
    data_loader_novel     = datamgr.get_data_loader(loadfile_novel, aug = False)
    
    if params.method == 'manifold_mixup':
        if params.dataset == 'XJTU':
            model = wrn_mixup_model.wrn28_10(40)
        else:
            model = wrn_mixup_model.wrn28_10(40)
    elif params.method == 'S2M2_R':
        if params.dataset == 'XJTU':
            # model = wrn_mixup_model.wrn28_10(100, loss_type = 'softmax')
            model = wrn_mixup_model.wrn28_10(40, 0.9)
        else:
            model = wrn_mixup_model.wrn28_10(40)
            wrn_mixup_model.wrn28_10(40 , 0.9)
    else:
        model = model_dict[params.model]()

    

    print(checkpoint_dir , modelfile)
    if params.method == 'manifold_mixup' or params.method == 'S2M2_R':
        if torch.cuda.is_available():
            model = model.cuda()
        tmp = torch.load(modelfile)
        state = tmp['state']
        state_keys = list(state.keys())
        callwrap = False
        if 'module' in state_keys[0]:
            callwrap = True

        if callwrap:
            model = WrappedModel(model) 

        model_dict_load = model.state_dict()
        model_dict_load.update(state)
        model.load_state_dict(model_dict_load)
    
    else:
        if torch.cuda.is_available():
            model = model.cuda()
        tmp = torch.load(modelfile)
        state = tmp['state']
        callwrap = False
        state_keys = list(state.keys())
        for i, key in enumerate(state_keys):
            if 'module' in key and callwrap == False:
                callwrap = True
            if "feature." in key:
                newkey = key.replace("feature.","")  # an architecture model has attribute 'feature', load architecture feature to backbone by casting name from 'feature.trunk.xx' to 'trunk.xx'  
                state[newkey] = state.pop(key)
            else:
                state.pop(key)
    
        if callwrap:
            model = WrappedModel(model) 
        model.load_state_dict(state)   



    model.eval()

    dirname_base = os.path.dirname(outfile_base)
    if not os.path.isdir(dirname_base):
        os.makedirs(dirname_base)
    dirname_novel = os.path.dirname(outfile_novel)
    if not os.path.isdir(dirname_novel):
        os.makedirs(dirname_novel)

    save_features(model, data_loader_base, outfile_base , params, split_base)
    save_features(model, data_loader_novel, outfile_novel , params, split_novel)
