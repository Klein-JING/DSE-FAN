pip3 install gdown

gdown --id 1pTsCCMDj45kzFYgrnO67BWVbKs48Q3NI --output ../../datas/cifar100.zip
unzip ../../datas/cifar100.zip -d ../../datas/
mv ../../datas/cifar100 ../../datas/cifar-FS
rm -rf ../../datas/cifar100.zip
python make_json.py
