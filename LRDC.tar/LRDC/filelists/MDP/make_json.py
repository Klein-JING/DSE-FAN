import glob
import json
import os


data_root = os.getcwd()
database = 'MDP'
ROOT_PATH = os.path.abspath(os.path.join(data_root, "../../datas/"+database)) 


train = {'label_names': [] , 'image_names':[] , 'image_labels':[]}
setname = "train"
classes = os.path.join(ROOT_PATH, setname)
lb = 0
for cls in os.listdir(classes):
	train['label_names'].append(cls)
	for cls_individual in os.listdir(os.path.join(classes, cls)):
		img_path = os.path.join(classes, cls, cls_individual)
		train['image_names'].append(img_path)
		train['image_labels'].append(lb)
	lb += 1
json.dump(train, open('XJTU_Conv4/S2M2_fewshot-master/filelists/MDP/base.json','w')) 


valid = {'label_names': [] , 'image_names':[] , 'image_labels':[]}
setname = "valid"
classes = os.path.join(ROOT_PATH, setname)
lb = 200
for cls in os.listdir(classes):
	valid['label_names'].append(cls)
	for cls_individual in os.listdir(os.path.join(classes, cls)):
		img_path = os.path.join(classes, cls, cls_individual)
		valid['image_names'].append(img_path)
		valid['image_labels'].append(lb)
	lb += 1
json.dump(valid, open('XJTU_Conv4/S2M2_fewshot-master/filelists/MDP/val.json','w')) 


test = {'label_names': [] , 'image_names':[] , 'image_labels':[]}
setname = "test"
classes = os.path.join(ROOT_PATH, setname)
lb = 260
for cls in os.listdir(classes):
	test['label_names'].append(cls)
	for cls_individual in os.listdir(os.path.join(classes, cls)):
		img_path = os.path.join(classes, cls, cls_individual)
		test['image_names'].append(img_path)
		test['image_labels'].append(lb)
	lb += 1
json.dump(test, open('XJTU_Conv4/S2M2_fewshot-master/filelists/MDP/novel.json','w')) 



# pathname = os.getcwd() + '/../../'
# test = {'label_names': [] , 'image_names':[] , 'image_labels':[]}
# f = open(pathname + 'datas/MDP-FS/splits/bertinetto/test.txt')
# classes = f.readlines()
# count = 80
# for each in classes: 
# 	each = each.strip()
# 	test['label_names'].append(each)
# 	files = glob.glob( pathname + 'datas/MDP-FS/data/' + each + '/*')
# 	for image_name in files:
# 		test['image_names'].append( image_name)
# 		test['image_labels'].append(count)
# 	count +=1
# json.dump(test , open('XJTU_Conv4/S2M2_fewshot-master/filelists/MDP/novel.json','w')) 


# base = {'label_names': [] , 'image_names':[] , 'image_labels':[]}
# f = open(pathname + 'datas/MDP-FS/splits/bertinetto/train.txt')
# classes = f.readlines()

# count = 0
# for each in classes: 
# 	each = each.strip()
# 	base['label_names'].append(each)
# 	files = glob.glob( pathname + 'datas/MDP-FS/data/' + each + '/*')
# 	for image_name in files:
# 		base['image_names'].append( image_name)
# 		base['image_labels'].append(count)
# 	count +=1
# json.dump(base , open('XJTU_Conv4/S2M2_fewshot-master/filelists/MDP/base.json','w')) 


# val = {'label_names': [] , 'image_names':[] , 'image_labels':[]}
# f = open(pathname + 'datas/MDP-FS/splits/bertinetto/val.txt')
# classes = f.readlines()

# count = 0
# for each in classes: 
# 	each = each.strip()
# 	val['label_names'].append(each)
# 	files = glob.glob( pathname + 'datas/MDP-FS/data/' + each + '/*')
# 	for image_name in files:
# 		val['image_names'].append( image_name)
# 		val['image_labels'].append(count)
# 	count +=1
# json.dump(val , open('XJTU_Conv4/S2M2_fewshot-master/filelists/MDP/val.json','w')) 