from model.models.base import FewShotModel
