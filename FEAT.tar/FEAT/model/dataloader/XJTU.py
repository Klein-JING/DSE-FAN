import os
import os.path as osp
from PIL import Image
import torch
from torch.utils.data import Dataset
from torchvision import transforms
import numpy as np

class XJTU(Dataset):
    def __init__(self, setname, args, augment=False):
        data = []
        label = []
        lb = -1
        data_root = os.getcwd()
        ROOT_PATH = os.path.abspath(os.path.join(data_root, "../../datas/XJTU")) 
        classes = osp.join(ROOT_PATH, setname)
        
        normalize = transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])        
        if augment and setname == 'train':
            flag = torch.rand(1)
            if flag>0.95:
                self.transform = transforms.Compose([transforms.RandomCrop(84, padding=2),
                                                    # transforms.ColorJitter(brightness=0.8, contrast=0.8, saturation=0.8),
                                                    # transforms.RandomRotation((0,5), resample=False, expand=False, center=None, fill=None),
                                                    transforms.ToTensor(), normalize])
            elif flag>0.9:
                self.transform = transforms.Compose([transforms.ColorJitter(brightness=0.9, contrast=0.9, saturation=0.9),
                                                        transforms.ToTensor(),normalize])
            elif flag>0.85:
                self.transform = transforms.Compose([transforms.RandomRotation((0,3), resample=False, expand=False, center=None, fill=None),
                                                        transforms.ToTensor(),normalize])
            else:
                self.transform = transforms.Compose([transforms.ToTensor(),normalize])
        else:
            self.transform = transforms.Compose([transforms.ToTensor(),normalize])

        for cls in os.listdir(classes):
            lb += 1
            for cls_individual in os.listdir(os.path.join(classes, cls)):
                img_path = os.path.join(classes, cls, cls_individual)
                data.append(img_path)
                label.append(lb)
        self.data = data
        self.label = label

        ##added for num_class
        self.num_class = np.unique(np.array(self.label)).shape[0]
    def __len__(self):
        return len(self.data)
    def __getitem__(self, i):
        path, label = self.data[i], self.label[i]
        img  =Image.open(path).convert('RGB')
        img = img.resize((84, 84)).convert('RGB')
        image = self.transform(img)
        return image, label