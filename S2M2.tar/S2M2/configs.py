
save_dir                    = 'XJTU_Conv4/S2M2_fewshot-master/'
data_dir = {}
data_dir['XJTU']             = 'XJTU_Conv4/S2M2_fewshot-master/filelists/XJTU/' 
data_dir['MDP']             = 'XJTU_Conv4/S2M2_fewshot-master/filelists/MDP/' 
data_dir['NUIG']    = 'XJTU_Conv4/S2M2_fewshot-master/filelists/NUIG/' 